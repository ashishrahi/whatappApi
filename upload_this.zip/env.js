const appVersion = "2.3";
const addON = [""];

module.exports = { appVersion, addON };
